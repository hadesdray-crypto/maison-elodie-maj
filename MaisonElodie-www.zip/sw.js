/* Maison Élodie : tout est gardé dans le téléphone, l'appli marche sans internet.
   Mises à jour : Réglages, Mises à jour (remplace 'index.html' dans le cache). Une APK plus récente prend aussi le dessus. */
const CACHE='me-shell',BUNDLE='11.17';
const FILES=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png'];
const ver=t=>{const m=/APP=\{version:'([\d.]+)'/.exec(t||'');return m?m[1]:'0'};
const newer=(a,b)=>{const x=a.split('.').map(Number),y=b.split('.').map(Number);for(let i=0;i<3;i++){if((x[i]||0)>(y[i]||0))return true;if((x[i]||0)<(y[i]||0))return false}return false};
async function refresh(c){try{const r=await fetch('index.html',{cache:'no-store'});if(!r.ok)return;const t=await r.text();const old=await c.match('index.html');const ot=old?await old.clone().text():'';
  if(!old||newer(ver(t),ver(ot))){const mk=()=>new Response(t,{headers:{'content-type':'text/html;charset=utf-8'}});await c.put('index.html',mk());await c.put('./',mk())}}catch(_){}}
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(async c=>{for(const f of FILES){try{if(!(await c.match(f)))await c.add(f)}catch(_){}}await refresh(c)}).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('message',e=>{if(e.data==='skipWaiting')self.skipWaiting()});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);if(u.origin!==location.origin)return;
  const nav=r.mode==='navigate',key=nav?'index.html':r;
  e.respondWith(caches.open(CACHE).then(async c=>{const hit=await c.match(key,{ignoreSearch:true});
    if(hit){if(nav)e.waitUntil(refresh(c));return hit}
    try{const res=await fetch(r);if(res&&res.ok)c.put(r,res.clone());return res}catch(_){const home=await c.match('index.html');return home||new Response('Hors ligne',{status:503})}}))});
